cs3250hw4artem

This is an ongoing project library that contains algorithms. 

The first project is a small program that solves Dijkstra's shortest path problem. 

Install package via command
#
pip install graphs_amarsh
#

